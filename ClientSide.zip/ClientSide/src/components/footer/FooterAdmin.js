import React from "react";
import {
  Flex,
  List,
  ListItem,
  Text,
  useColorMode,
  useColorModeValue,
  Link,
  useDisclosure, // Import useDisclosure hook
} from "@chakra-ui/react";
import TermsModal from "./TermsModal"; // Import the modal component

export default function Footer() {
  const textColor = useColorModeValue("gray.400", "white");
  const { toggleColorMode } = useColorMode();

  // Use useDisclosure to manage the modal state
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <Flex
      zIndex="3"
      flexDirection={{
        base: "column",
        xl: "row",
      }}
      alignItems={{
        base: "center",
        xl: "start",
      }}
      justifyContent="space-between"
      px={{ base: "30px", md: "50px" }}
      pb="30px"
    >
      <Text
        color={textColor}
        textAlign={{
          base: "center",
          xl: "start",
        }}
        mb={{ base: "20px", xl: "0px" }}
      >
        {" "}
        &copy; {1900 + new Date().getYear()}
        <Text as="span" fontWeight="500" ms="4px">
          MY EYE. All Rights Reserved. Made with love by
          <Link
            mx="3px"
            color={textColor}
            href="#"
            target="_blank"
            fontWeight="700"
          >
            MY-EYE!
          </Link>
        </Text>
      </Text>
      <List display="flex">
        <ListItem me={{ base: "20px", md: "44px" }}>
          <Link
            fontWeight="500"
            color={textColor}
            href="mailto:kadarisaikrishna112@gmail.com?subject=Subject&body=Body"
          >
            Support
          </Link>
        </ListItem>
        <ListItem me={{ base: "20px", md: "44px" }}>
          <Link
            fontWeight="500"
            color={textColor}
            onClick={onOpen}
            cursor="pointer" // Add pointer cursor to make it look like a link
          >
            Terms and Conditions
          </Link>
        </ListItem>
      </List>
      {/* TermsModal component will display when the "Terms of Use" link is clicked */}
      <TermsModal isOpen={isOpen} onClose={onClose} />
    </Flex>
  );
}
