// Daily Traffic Dashboards Defaul

// export const barChartDataDailyTraffic = [
//   {
//     name: "Course Complition Rate",
//     data: [20, 30, 40, 20, 45, 50]
//   }
// ];
export const generateBarChartData = (completionsData, enrollsData, unvisitedData) => {
  return [
    {
      name: "Completions",
      data: completionsData,
    },
    {
      name: "Enrolls",
      data: enrollsData,
    },
    {
      name: "Unvisited",
      data: unvisitedData,
    },
  ];
};
export const barChartOptionsDailyTraffic = {
  chart: {
    toolbar: {
      show: false
    }
  },
  tooltip: {
    style: {
      fontSize: "12px",
      fontFamily: undefined
    },
    onDatasetHover: {
      style: {
        fontSize: "12px",
        fontFamily: undefined
      }
    },
    theme: "dark",
    x: {
      show: false // Hide the x-axis tooltip
    },
    y: {
      formatter: function (val) {
        return val + '%'; // Display the values as percentages
      },
      title: {
        formatter: function () {
          return 'Completion Rate:';
        }
      }
    }
  },
  xaxis: {
    categories: ["GDC", "ANZ", "Eu East", "NA", "Ind", "Eu West"],
    show: false,
    labels: {
      show: true,
      style: {
        colors: "#A3AED0",
        fontSize: "14px",
        fontWeight: "500"
      }
    },
    axisBorder: {
      show: false
    },
    axisTicks: {
      show: false
    }
  },
  yaxis: {
    show: false,
    color: "black",
    labels: {
      show: true,
      style: {
        colors: "#CBD5E0",
        fontSize: "14px"
      }
    }
  },
  grid: {
    show: false,
    strokeDashArray: 5,
    yaxis: {
      lines: {
        show: true
      }
    },
    xaxis: {
      lines: {
        show: false
      }
    }
  },
  fill: {
    type: "gradient",
    gradient: {
      type: "vertical",
      shadeIntensity: 1,
      opacityFrom: 0.7,
      opacityTo: 0.9,
      colorStops: [
        [
          {
            offset: 0,
            color: "#4318FF",
            opacity: 1
          },
          {
            offset: 100,
            color: "rgba(67, 24, 255, 1)",
            opacity: 0.28
          }
        ]
      ]
    }
  },
  dataLabels: {
    enabled: false
  },
  plotOptions: {
    bar: {
      borderRadius: 10,
      columnWidth: "40px"
    }
  }
};
// Consumption Users Reports
export const barChartDataConsumption = [
  {
    name: "Completions",
    data: [400, 370, 330, 390, 320, 350, 360, 320, 380],
  },
  {
    name: "Enrolls",
    data: [400, 370, 330, 390, 320, 350, 360, 320, 380],
  },
  {
    name: "Unvisited",
    data: [400, 370, 330, 390, 320, 350, 360, 320, 380],
  },
];
export const barChartOptionsConsumption = {
  chart: {
    stacked: true,
    toolbar: {
      show: false,
    },
  },
  tooltip: {
    style: {
      fontSize: "12px",
      fontFamily: undefined,
    },
    onDatasetHover: {
      style: {
        fontSize: "12px",
        fontFamily: undefined,
      },
    },
    theme: "dark",
  },
  xaxis: {
    categories: ["GDC","ANZ","EU-East","NA","INDIA","EU-west"],
    show: false,
    labels: {
      show: true,
      style: {
        colors: "#A3AED0",
        fontSize: "14px",
        fontWeight: "500",
      },
    },
    axisBorder: {
      show: false,
    },
    axisTicks: {
      show: false,
    },
  },
  yaxis: {
    show: false,
    color: "black",
    labels: {
      show: false,
      style: {
        colors: "#A3AED0",
        fontSize: "14px",
        fontWeight: "500",
      },
    },
  },
  grid: {
    borderColor: "rgba(163, 174, 208, 0.3)",
    show: true,
    yaxis: {
      lines: {
        show: false,
        opacity: 0.5,
      },
    },
    row: {
      opacity: 0.5,
    },
    xaxis: {
      lines: {
        show: false,
      },
    },
  },
  fill: {
    type: "solid",
    colors: ["#5E37FF", "#E1E9F8", "#6AD2FF"],
  },
  legend: {
    show: false,
  },
  colors: ["#5E37FF", "#E1E9F8", "#6AD2FF"],
  dataLabels: {
    enabled: false,
  },
  plotOptions: {
    bar: {
      borderRadius: 10,
      columnWidth: "20px",
    },
  },
};
export const barChartOptionsConsumption1 = {
  chart: {
    stacked: true,
    toolbar: {
      show: false,
    },
  },
  tooltip: {
    style: {
      fontSize: "12px",
      fontFamily: undefined,
    },
    onDatasetHover: {
      style: {
        fontSize: "12px",
        fontFamily: undefined,
      },
    },
    theme: "dark",
  },
  xaxis: {
    categories: ["BSS","ES","EDS","EBS","IBS","RBS"],
    show: false,
    labels: {
      show: true,
      style: {
        colors: "#A3AED0",
        fontSize: "14px",
        fontWeight: "500",
      },
    },
    axisBorder: {
      show: false,
    },
    axisTicks: {
      show: false,
    },
  },
  yaxis: {
    show: false,
    color: "black",
    labels: {
      show: false,
      style: {
        colors: "#A3AED0",
        fontSize: "14px",
        fontWeight: "500",
      },
    },
  },
  grid: {
    borderColor: "rgba(163, 174, 208, 0.3)",
    show: true,
    yaxis: {
      lines: {
        show: false,
        opacity: 0.5,
      },
    },
    row: {
      opacity: 0.5,
    },
    xaxis: {
      lines: {
        show: false,
      },
    },
  },
  fill: {
    type: "solid",
    colors: ["#5E37FF", "#E1E9F8", "#6AD2FF"],
  },
  legend: {
    show: false,
  },
  colors: ["#5E37FF", "#E1E9F8", "#6AD2FF"],
  dataLabels: {
    enabled: false,
  },
  plotOptions: {
    bar: {
      borderRadius: 10,
      columnWidth: "20px",
    },
  },
};
export const pieChartOptions = {
  labels: ["Your files", "System", "Empty"],
  colors: ["#4318FF", "#6AD2FF", "#EFF4FB"],
  chart: {
    width: "50px",
  },
  states: {
    hover: {
      filter: {
        type: "none",
      },
    },
  },
  legend: {
    show: false,
  },
  dataLabels: {
    enabled: false,
  },
  hover: { mode: null },
  plotOptions: {
    donut: {
      expandOnClick: false,
      donut: {
        labels: {
          show: false,
        },
      },
    },
  },
  fill: {
    colors: ["#4318FF", "#6AD2FF", "#EFF4FB"],
  },
  tooltip: {
    enabled: true,
    theme: "dark",
  },
};
export const pieChartData = [63, 25, 12];
// Total Spent Default
// export const lineChartDataTotalSpent = [
//   {
//     name: "Completion",
//     data: [251, 1077, 209, 340],
//   },
//   {
//     name: "Enrolls",
//     data: [524, 1633, 733, 1013],
//   },
// ];
// export const generateBarChartData1 = (completionsData2, enrollsData2) => {
//   return [
//     {
//       name: "Completions",
//       data: completionsData2,
//     },
//     {
//       name: "Enrolls",
//       data: enrollsData2,
//     },
//   ];
// };
export const lineChartOptionsTotalSpent = {
  chart: {
    toolbar: {
      show: false,
    },
    dropShadow: {
      enabled: true,
      top: 13,
      left: 0,
      blur: 10,
      opacity: 0.1,
      color: "#4318FF",
    },
  },
  colors: ["#4318FF", "#39B8FF"],
  markers: {
    size: 0,
    colors: "white",
    strokeColors: "#7551FF",
    strokeWidth: 3,
    strokeOpacity: 0.9,
    strokeDashArray: 0,
    fillOpacity: 1,
    discrete: [],
    shape: "circle",
    radius: 2,
    offsetX: 0,
    offsetY: 0,
    showNullDataPoints: true,
  },
  tooltip: {
    theme: "dark",
  },
  dataLabels: {
    enabled: false,
  },
  stroke: {
    curve: "smooth",
    type: "line",
  },
  xaxis: {
    type: "category",
    categories: generateMonthLabels(),
    labels: {
      style: {
        colors: "#A3AED0",
        fontSize: "12px",
        fontWeight: "500",
      },
    },
    axisBorder: {
      show: false,
    },
    axisTicks: {
      show: false,
    },
  },
  yaxis: {
    show: false,
  },
  legend: {
    show: false,
  },
  grid: {
    show: false,
    column: {
      color: ["#7551FF", "#39B8FF"],
      opacity: 0.5,
    },
  },
  color: ["#7551FF", "#39B8FF"],
};
function generateMonthLabels() {
  const currentDate = new Date();
  const monthLabels = [];
  for (let i = 0; i < 4; i++) {
    const month = currentDate.toLocaleString("default", { month: "short" });
    monthLabels.unshift(month.toUpperCase());
    currentDate.setMonth(currentDate.getMonth() - 1);
  }
  return monthLabels;
}
function generateDateLabels() {
  const currentDate = new Date();
  const dateLabels = [];
  for (let i = 0; i < 9; i++) {
    const day = currentDate.getDate();
    dateLabels.unshift(day.toString());
    currentDate.setDate(currentDate.getDate() - 1);
  }
  return dateLabels;
}
function generateDateLabelsSeven() {
  const currentDate = new Date();
  const dateLabels = [];
  for (let i = 0; i < 7; i++) {
    const day = currentDate.getDate();
    dateLabels.unshift(day.toString());
    currentDate.setDate(currentDate.getDate() - 1);
  }
  return dateLabels;
}