import {
  Box,
  Flex,
  FormLabel,
  Icon,
  Select,
  SimpleGrid,
  useColorModeValue
} from "@chakra-ui/react";
//import { useToast } from '@chakra-ui/react'
import MiniStatistics from "components/card/MiniStatistics";
import IconBox from "components/icons/IconBox";
import React, { useState,useEffect } from "react";
import BuWisePieChart from "components/charts/MiniBuWisePieChart";
import MiniStatisticsRegionWise from "components/card/MiniStatisticsRegionwise";
import MiniStatisticsbuwise from "components/card/MiniStatisticsBUwise"
 
import {
  MdTimelapse,
  MdVideoStable,
  MdMultipleStop,
  MdPeople
} from "react-icons/md";
import DailyTraffic from "views/admin/default/components/DailyTraffic";
import TotalSpent from "views/admin/default/components/TotalSpent";
import WeeklyRevenue from "views/admin/default/components/WeeklyRevenue";

 
 
export default function UserReports() {
 
  const [totalUsersCount,totalUsersCountChange] = useState(0);
  const [totaCoursesCount,totalCoursesCountChange] = useState(0);
  const [usersData,usersDataChange] = useState(null);
 
  const [usersBUWiseCount,usersBUWiseCountChange] = useState(0);
  const [selectedBU,setSelectedBU]=useState('EBS');
 
  const [usersRegWiseCount,usersRegWiseCountChange] = useState(0);
  const [selectedReg,setSelectedReg]=useState('Ind');
 
  const[enterprisecount,usersenterprisecountchange]=useState(0);
  const[procount,userprocountchange]=useState(0);
 
  const[buenterprisecount,userbuenterprisecountchange]=useState(0);
  const[buprocount,userbuprocountchange]=useState(0);
 
 
  const [totalPathsCount,totalPathsCountChange]=useState(0);
  const [completionRate,setCompletionRate]=useState(0);
 
 
 
  useEffect(()=>{
    fetch("http://localhost:3001/api/course-list").then((resp)=>{
      return resp.json();
    }).then((res)=>{
      totalCoursesCountChange(res.count);
    }).catch((err)=>{
      console.log(err.message);
    })
  })
  useEffect(()=>{
    fetch("http://localhost:3001/api/all-data").then((resp)=>{
      return resp.json();
    }).then((res)=>{
      usersDataChange(res.Users);
      const BU_InitialCount = calculateBUWiseCount(res.Users, selectedBU);
      usersBUWiseCountChange(BU_InitialCount);
 
      const buwiseenterprisecount=bucalculateEnterpriseCount(res.Users,selectedBU);
      userbuenterprisecountchange(buwiseenterprisecount);
      const buwiseprocount=bucalculateproCount(res.Users,selectedBU);
      userbuprocountchange(buwiseprocount);
      const regInitialCount = calculateRegWiseCount(res.Users, selectedReg);
      usersRegWiseCountChange(regInitialCount);
      const pathsCount = calculatePathsCount(res.Users);
      totalPathsCountChange(pathsCount);
      totalUsersCountChange(res.Users.length);
      calculateCompletionRate(res.Users);
      const rate=Math.ceil(totalCompletedCourses*100/totalEnrolledCourses);
      rate===0?setCompletionRate(0):setCompletionRate(rate);
      const enterpriseCount=calculateEnterpriseCount(res.Users,selectedReg);
      usersenterprisecountchange(enterpriseCount);
      const proCount=calculateproCount(res.users,selectedReg);
      userprocountchange(proCount);
 
     
    }).catch((err)=>{
      console.log(err.message);
    })
  },[])
 
  const brandColor = useColorModeValue("brand.500", "white");
  const boxBg = useColorModeValue("secondaryGray.300", "whiteAlpha.100");
  const handleBUChange = (e)=>{
    const newBU = e.target.value;
    setSelectedBU(newBU);
    const count = calculateBUWiseCount(usersData,newBU);
    usersBUWiseCountChange(count);
    const buenterpriseCount=bucalculateEnterpriseCount(usersData,newBU)
    userbuenterprisecountchange(buenterpriseCount);
    const buproCount=bucalculateproCount(usersData,newBU)
    userbuprocountchange(buproCount);
  }
  const handleRegChange = (e)=>{
    const newReg = e.target.value;
    setSelectedReg(newReg);
    const count = calculateRegWiseCount(usersData,newReg);
    usersRegWiseCountChange(count);
    const enterpriseCount=calculateEnterpriseCount(usersData,newReg);
    usersenterprisecountchange(enterpriseCount);
    const proCount=calculateproCount(usersData,newReg);
     userprocountchange(proCount);
     
  }
  const calculateRegWiseCount = (users,reg)=>{
    return users.filter((user)=>user.Region === reg).length;
  }
  const calculateBUWiseCount = (users, bu) => {
    return users.filter((user) => user.BU === bu).length;
  };
  const uniquePaths = new Set();
  const calculatePathsCount = (users) =>{
    users.forEach((user)=>{
      user.Paths.forEach((path)=>{
        uniquePaths.add(path.path_id);
      })
    })
    return uniquePaths.size;
  }
  const calculateEnterpriseCount = (users, selectedRegion) => {
    let enterpriseCount = 0;
 
    users.forEach((user) => {
      const region = user.Region;
      if (region === selectedRegion && user.LisenceType === "Enterprise") {
        enterpriseCount += 1;
      }
    });
 
    return enterpriseCount;
  };
  const calculateproCount = (users, selectedRegion) => {
    let proCount = 0;
    users.forEach((user) => {
      const region = user.Region;
      if (region === selectedRegion && user.LisenceType === "Enterprise, Pro") {
        proCount += 1;
      }
    });
    return proCount;
  };
  const bucalculateEnterpriseCount = (users, selectedBU) => {
   
    let enterpriseBuCount = 0;
    users.forEach((user) => {
      const userBU = user.BU;
      if (userBU === selectedBU && user.LisenceType === "Enterprise") {
        enterpriseBuCount += 1;
      }
    });
 
    return enterpriseBuCount;
  };
  const bucalculateproCount = (users, selectedBU) => {
    let proBucount = 0;
    users.forEach((user) => {
      const BU = user.BU;
      if (BU === selectedBU && user.LisenceType === "Enterprise, Pro") {
        proBucount += 1;
      }
    });
 
    return proBucount;
  };
  let totalEnrolledCourses=0;
  let totalCompletedCourses=0;
  const calculateCompletionRate = (users)=>{
    users.forEach((user)=>{
      if(typeof user.num_new_enrolled_courses==='number' && typeof user.num_completed_courses==='number'){
        totalEnrolledCourses += user.num_new_enrolled_courses;
        totalCompletedCourses += user.num_completed_courses;
      }
    })
  }
 // const toast = useToast()
  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
      <SimpleGrid
        columns={{ base: 1, md: 2, lg: 3, "2xl": 6 }}
        gap='20px'
        mb='20px'>
        <MiniStatistics
          startContent={
            <IconBox
              w='56px'
              h='56px'
              bg={boxBg}
              icon={
                <Icon w='32px' h='32px' as={MdTimelapse} color={brandColor} />
              }
            />
          }
          name='Completion rate'
          value={`${completionRate}%`}
        />
        <MiniStatisticsRegionWise
          endContent={
            <Flex me='-16px' mt='10px'>
              <FormLabel htmlFor='balance'>
                {/* <Avatar src={} /> */}
              </FormLabel>
              <Select
               fontSize="sm"
               variant="filled"
               width="unset"
               fontWeight="700"
               onChange={handleRegChange}>
                <option value='Ind'>IND</option>
                <option value='NA'>NA</option>
                <option value='Eu East'>EU EAST</option>
                <option value='Eu West'>EU WEST</option>
                <option value='ANZ'>ANZ</option>
                <option value='GDC'>GDC</option>
              </Select>
            </Flex>
          }
          name='Region wise users'
          value={usersRegWiseCount}
          enterpriseCount={enterprisecount}
          proCount={procount}
        />
       
        <MiniStatisticsbuwise
          endContent={
            <Flex me='-16px' mt='10px'>
              <FormLabel htmlFor='balance'>
                {/* <Avatar src={} /> */}
              </FormLabel>
              <Select
               fontSize="sm"
               variant="filled"
               width="unset"
               fontWeight="700"
               onChange={handleBUChange}>
                <option value='EBS'>EBS</option>
                <option value='EDS'>EDS</option>
                <option value='ES'>ES</option>
                <option value='BSS'>BSS</option>
              </Select>
            </Flex>
          }
          name='BU wise users'
          value={usersBUWiseCount}
          enterpriseCount={buenterprisecount}
          proCount={buprocount}
        />
        <MiniStatistics
          startContent={
            <IconBox
              w='56px'
              h='56px'
              bg='linear-gradient(90deg, #4481EB 0%, #04BEFE 100%)'
              icon={<Icon w='28px' h='28px' as={MdMultipleStop} color='white' />}
            />
          }
          name='Total Paths'
          value={totalPathsCount}
        />
        <MiniStatistics
        startContent={
          <IconBox
            w='56px'
            h='56px'
            bg={boxBg}
            icon={
              <Icon w='32px' h='32px' as={MdVideoStable} color={brandColor} />
            }
          />
        }
         name='Total courses' value={totaCoursesCount} />
        <MiniStatistics
          startContent={
            <IconBox
              w='56px'
              h='56px'
              bg={boxBg}
              icon={
                <Icon w='32px' h='32px' as={MdPeople} color={brandColor} />
              }
            />
          }
          name='Total Users'
          value= {totalUsersCount}
        />
       
      </SimpleGrid>
     
      <SimpleGrid  gap='20px' mb='20px'>  
        <BuWisePieChart/>
      </SimpleGrid>
      <SimpleGrid  gap='20px' mb='20px'>
        <DailyTraffic />
      </SimpleGrid>
      <SimpleGrid columns={{ base: 1, md: 2, xl: 2 }} gap='15px' mb='20px'>
        <TotalSpent />
        <WeeklyRevenue />
      </SimpleGrid>
    </Box>
  );
}