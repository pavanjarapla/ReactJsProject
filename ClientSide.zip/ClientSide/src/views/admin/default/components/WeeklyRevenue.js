import React, { useEffect, useState } from "react";
import { VSeparator } from "components/separator/Separator";
import {
  HStack,
  Radio,
  RadioGroup,
  Tooltip,
} from "@chakra-ui/react";
import {
  Box,
  Button,
  Flex,
  Icon,
  Text,
  useColorModeValue,
 
} from "@chakra-ui/react";
import Card from "components/card/Card.js";
import BarChart from "components/charts/BarChart";
import { barChartOptionsConsumption, barChartOptionsConsumption1 } from "variables/charts";
import { MdBarChart, MdStackedBarChart } from "react-icons/md";
import { generateBarChartData } from "variables/charts";

export default function WeeklyRevenue(props) {
  const { ...rest } = props;
  const [completions, setCompletions] = useState([]);
  const [enrollments, setEnrollments] = useState([]);
  const [unvisited, setUnvisited] = useState([]);
  const [regions, setRegions] = useState([]);
  const [barChartDataConsumption, setBarChartDataConsumption] = useState(null);
  const currentDate = new Date();
  const firstDayOfWeek = new Date(currentDate);
  firstDayOfWeek.setHours(
    0,
    0,
    0,
    0 - currentDate.getDay() * 24 * 60 * 60 * 1000
  );
  const lastDayOfWeek = new Date(currentDate);
  lastDayOfWeek.setDate(lastDayOfWeek.getDate() + (6 - currentDate.getDay()));
  const [selectedOption, setSelectedOption] = useState("Region");
  const [options,setOptions]=useState(barChartOptionsConsumption1);
  const formatDate = (date) => {
    const day = date.getDate();
    const month = date.toLocaleString("default", { month: "short" });
    return `${day}${
      day % 10 === 1 && day !== 11
        ? "st"
        : day % 10 === 2 && day !== 12
        ? "nd"
        : day % 10 === 3 && day !== 13
        ? "rd"
        : "th"
    } ${month}`;
  };
  const formattedFirstDay = formatDate(firstDayOfWeek);
  const formattedLastDay = formatDate(lastDayOfWeek);
  const textColor = useColorModeValue("secondaryGray.900", "white");
  const iconColor = useColorModeValue("brand.500", "white");
  const bgButton = useColorModeValue("secondaryGray.300", "whiteAlpha.100");
  const bgHover = useColorModeValue({ bg: "secondaryGray.400" }, { bg: "whiteAlpha.50" });
  const bgFocus = useColorModeValue({ bg: "secondaryGray.300" }, { bg: "whiteAlpha.100" });
  useEffect(() => {
    async function fetchDataAndProcessData() {
      async function fetchData() {
        const apiUrl = 'http://localhost:3001/api/all-data'; // Replace with your API URL
        try {
          const response = await fetch(apiUrl);
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          const data = await response.json();
          return data.Users; // Extract the Users array from the data
        } catch (error) {
          console.error('Error fetching data:', error);
          return null;
        }
      }
    function isDateInCurrentWeek(date) {
      const currentDate = new Date();
      const firstDayOfWeek = new Date(currentDate);
      firstDayOfWeek.setHours(
        0,
        0,
        0,
        0 - currentDate.getDay() * 24 * 60 * 60 * 1000
      );
      const providedDate = new Date(date);
      currentDate.setHours(0, 0, 0, 0);
      providedDate.setHours(0, 0, 0, 0);
      return providedDate >= firstDayOfWeek && providedDate <= currentDate;
    }
    const results = {};
    function processUserData(users) {
      users.forEach((user) => {
        let category;
        if (selectedOption === "Region") {
          category = user.Region;
          setOptions(barChartOptionsConsumption);
        } else if (selectedOption === "BU") {
          category = user.BU; // Replace "BU" with the actual property in your data
          setOptions(barChartOptionsConsumption1);
        }
        if (!results[category]) {
          results[category] = {
            completions: 0,
            enrollments: 0,
            unvisited: 0,
          };
        }
        const last_date_visit = user.last_date_visit;
        if (!isDateInCurrentWeek(last_date_visit)) {
          results[category].unvisited++;
        }
        user.Paths.forEach((path) => {
          path.courses.forEach((course) => {
            const enrollDate = new Date(course.course_enroll_date);
            const course_last_accessed_date = new Date(
              course.course_last_accessed_date
            );
            if (isDateInCurrentWeek(enrollDate)) {
              results[category].enrollments++;
              if (
                course.completion_ratio === 100 &&
                isDateInCurrentWeek(course_last_accessed_date)
              ) {
                results[category].completions++;
              }
            }
          });
        });
      });
    }
    function getCompletionsArray() {
      const completionsArray = [];
      for (const category in results) {
        if (results.hasOwnProperty(category)) {
          completionsArray.push(results[category].completions);
        }
      }
      return completionsArray;
    }
    function getEnrollmentsArray() {
      const enrollmentsArray = [];
      for (const category in results) {
        if (results.hasOwnProperty(category)) {
          enrollmentsArray.push(results[category].enrollments);
        }
      }
      return enrollmentsArray;
    }
    function getUnvisitedArray() {
      const unvisitedArray = [];
      for (const category in results) {
        if (results.hasOwnProperty(category)) {
          unvisitedArray.push(results[category].unvisited);
        }
      }
      return unvisitedArray;
    }
    function getCategoriesArray() {
      const categoriesArray = [];
      for (const category in results) {
        if (results.hasOwnProperty(category)) {
          categoriesArray.push(category);
        }
      }
      return categoriesArray;
    }
    function printCategoryWiseData() {
      for (const category in results) {
        if (results.hasOwnProperty(category)) {
          const categoryData = results[category];
        }
      }
    }
    let apiData;
    const data = await fetchData();
    if (data) {
      apiData = data;
      await processUserData(apiData);
      const completionsByCategory = getCompletionsArray();
      const enrollmentsByCategory = getEnrollmentsArray();
      const unvisitedByCategory = getUnvisitedArray();
      const categoriesArray = getCategoriesArray();
      setCompletions(completionsByCategory);
      setEnrollments(enrollmentsByCategory);
      setUnvisited(unvisitedByCategory);
      setRegions(categoriesArray);
       printCategoryWiseData();
      const updatedBarChartData = generateBarChartData(
        completionsByCategory,
        enrollmentsByCategory,
        unvisitedByCategory
      );
      setBarChartDataConsumption(updatedBarChartData);
    }
  }
    fetchDataAndProcessData();
  },[selectedOption])
  const generateTooltipContent = (categories, values) => {
    return (
      <ul>
        {categories.map((category, index) => (
          <li key={category}>
            {category}: {values[index]}
          </li>
        ))}
      </ul>
    );
  };
  
  return (barChartDataConsumption&&
    <Card align="center" direction="column" w="100%" {...rest}>
      <Flex align="center" w="100%" px="15px" py="10px">
        <Text me="auto" color={textColor} fontSize="2xl" fontWeight="700" lineHeight="100%">
          Weekly Report &nbsp; &nbsp; &nbsp;{" "}
          <span style={{ fontSize: "14px" }}>[{formattedFirstDay}</span> -{" "}
          <span style={{ fontSize: "14px" }}>{formattedLastDay}]</span>
        </Text>
        <Button
          align="center"
          justifyContent="center"
          bg={bgButton}
          _hover={bgHover}
          _focus={bgFocus}
          _active={bgFocus}
          w="37px"
          h="37px"
          lineHeight="100%"
          borderRadius="10px"
          {...rest}
        >
          <Icon as={MdStackedBarChart} color={iconColor} w="24px" h="24px" />
        </Button>
      </Flex>
      {/* Radio buttons for selecting Region or BU */}
      <RadioGroup
        defaultValue="Region"
        value={selectedOption}
        onChange={setSelectedOption}
      >
        <HStack spacing="24px">
          <Radio value="Region">Region</Radio>
          <Radio value="BU">BU</Radio>
        </HStack>
      </RadioGroup>
      <Flex direction="column" py="5px">
        <Flex align="center">
          <Box h="8px" w="8px" bg="brand.500" borderRadius="50%" me="4px" />
          <Tooltip label={generateTooltipContent(regions, completions)} hasArrow>
            <Text fontSize="xs" color="brand.500" fontWeight="700" mb="5px">
              Completed Courses
            </Text>
          </Tooltip>
        </Flex>
      </Flex>
      <VSeparator mx={{ base: "60px", xl: "60px", "2xl": "60px" }} />
      <Flex direction="column" py="5px" me="10px">
        <Flex align="center">
          <Box h="8px" w="8px" bg="secondaryGray.600" borderRadius="50%" me="4px" />
          <Tooltip label={generateTooltipContent(regions, enrollments)} hasArrow>
            <Text fontSize="xs" color="secondaryGray.600" fontWeight="700" mb="5px">
              Enrolled Courses
            </Text>
          </Tooltip>
        </Flex>
      </Flex>
      <VSeparator mx={{ base: "60px", xl: "60px", "2xl": "60px" }} />
      <Flex direction="column" py="5px" me="10px">
        <Flex align="center">
          <Box h="8px" w="8px" bg="#6AD2FF" borderRadius="50%" me="4px" />
          <Tooltip label={generateTooltipContent(regions, unvisited)} hasArrow>
            <Text fontSize="xs" color="#6AD2FF" fontWeight="700" mb="5px">
              Unvisited Users
            </Text>
          </Tooltip>
        </Flex>
      </Flex>
      <Box h="240px" mt="auto">
        {barChartDataConsumption.length > 0 && (
          <BarChart
            chartData={barChartDataConsumption}
            chartOptions={options}
          />
        )}
      </Box>
    </Card>
  );
}
