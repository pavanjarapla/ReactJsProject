import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';

function MealItem() {
  const { id } = useParams();
  const [description, setDescription] = useState('');

  useEffect(() => {
    const fetchIngredientDetails = async () => {
      try {
        const response = await fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?iid=${id}`);
        if (response.ok) {
          const data = await response.json();
          if (data && data.meals && data.meals.length > 0) {
            setDescription(data.meals[0].strDescription);
          }
        } else {
          throw new Error('Failed to fetch ingredient details');
        }
      } catch (error) {
        console.error('Error fetching ingredient details:', error);
      }
    };

    fetchIngredientDetails();
  }, [id]);

  return (
    <div>
      <h1>Meal Item Details</h1>
      <h2>ID: {id}</h2>
      <p>Description: {description}</p>
    </div>
  );
}

export default MealItem;
