import React, { useEffect, useMemo, useState } from "react";
import { useHistory } from "react-router-dom";
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Button,
  Select,
  Stack,
  Input,
  Text,
  Spacer,
} from "@chakra-ui/react";

function Meals(props) {
  const { tableData } = props;
  const history = useHistory();
  const [filteredData, setFilteredData] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(5); // Changed page size to 5

  useEffect(() => {
    setFilteredData(tableData);
  }, [tableData]);

  const handleCategoryChange = (e) => {
    setSelectedCategory(e.target.value);
    setPageIndex(0);
  };

  const changeEventHandler = (e) => {
    setSearchQuery(e.target.value.toLowerCase());
    setPageIndex(0);
  };

  const handleClick = (id) => {
    history.push(`/meal-item/${id}`);
  };

  const filteredItems = useMemo(() => {
    let filtered = filteredData;
    if (selectedCategory !== "All") {
      filtered = filtered.filter(
        (item) => item.strIngredient === selectedCategory
      );
    }
    if (searchQuery) {
      filtered = filtered.filter((item) =>
        item.strIngredient.toLowerCase().includes(searchQuery)
      );
    }
    return filtered;
  }, [filteredData, selectedCategory, searchQuery]);

  const paginatedItems = useMemo(() => {
    const startIndex = pageIndex * pageSize;
    return filteredItems.slice(startIndex, startIndex + pageSize);
  }, [filteredItems, pageIndex, pageSize]);

  return (
    <div>
      <Spacer />
      <Spacer />
      <Spacer />
      <Spacer />
      <Spacer />

      <div
        style={{
          display: "flex",
          alignItems: "center",
          marginBottom: "10px",
        }}
      >
        <Select
          value={selectedCategory}
          onChange={handleCategoryChange}
          style={{ marginRight: "10px" }}
        >
          <option value="All">All Categories</option>
          {tableData.map((item) => (
            <option
              key={item.idIngredient}
              value={item.strIngredient}
            >
              {item.strIngredient}
            </option>
          ))}
        </Select>
        <Input
          placeholder="Search..."
          value={searchQuery}
          onChange={changeEventHandler}
        />
      </div>
      <Table>
        <Thead>
          <Tr>
            <Th>Id</Th>
            <Th>Product Name</Th>
            <Th>Description</Th>
          </Tr>
        </Thead>
        <Tbody>
          {paginatedItems.map((item) => (
            <Tr key={item.idIngredient}>
              <Td>{item.idIngredient}</Td>
              <Td>
                <Button onClick={() => handleClick(item.idIngredient)}>
                  {item.strIngredient}
                </Button>
              </Td>
              <Td>{item.strDescription}</Td> {/* Accessing description directly */}
            </Tr>
          ))}
        </Tbody>
      </Table>
      <Stack direction="row" spacing={4} mt={4}>
        <Button
          onClick={() =>
            setPageIndex((prev) => Math.max(prev - 1, 0))
          }
        >
          Previous
        </Button>
        <Text>
          Page {pageIndex + 1} of {Math.ceil(filteredItems.length / pageSize)}
        </Text>
        <Button
          onClick={() =>
            setPageIndex((prev) =>
              Math.min(
                prev + 1,
                Math.ceil(filteredItems.length / pageSize) - 1
              )
            )
          }
        >
          Next
        </Button>
      </Stack>
    </div>
  );
}

export default Meals;
