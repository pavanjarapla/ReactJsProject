
import React from 'react';
import Meals from './components/Meals';
import { useState,useEffect } from 'react';
function Receipe() {
    // Component logie
    const [ingredients, setIngredients] = useState([]);
    
    useEffect(() => {
      const fetchIngredients = async () => {
        try {
          const response = await fetch('https://www.themealdb.com/api/json/v1/1/list.php?i=list');
          if (response.ok) {
            const data = await response.json();
            if (data && data.meals) {
              setIngredients(data.meals);
            }
          } else {
            throw new Error('Failed to fetch ingredients');
          }
        } catch (error) {
          console.error('Error fetching ingredients:', error);
        }
      };
  
      fetchIngredients();
    }, []);
  if(ingredients)
  {
   console.log(ingredients)
  }
    return(
        <>
        <Meals  tableData={ingredients}/>
        
        </>
    )
}

export default Receipe;
