import React from "react";

import { Icon } from "@chakra-ui/react";
import {
  MdPerson,
  MdHome,
  MdLock,
  MdPeople,
  MdTableChart,
  MdDiamond,
} from "react-icons/md";

// Admin Imports
import Receipe from "views/admin/receipe/index"



import MealItem from "views/admin/receipe/components/MealItem";

//import RTL from "views/admin/rtl";

// Auth Imports
import SignInCentered from "views/auth/signIn";


const routes = [
  {
    name: "Sign In",
    layout: "/auth",
    path: "/sign-in",
    hidden: true,
    icon: <Icon as={MdLock} width="20px" height="20px" color="inherit" />,
    component: SignInCentered,
  },
  {
    name: "Receipe",
    layout: "/admin",
    path: "/receipe",
    icon: <Icon as={MdHome} width="20px" height="20px" color="inherit" />,
    component: Receipe,
  },


  
];

export default routes;
